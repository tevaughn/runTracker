//
//  Interval.m
//  Runner
//
//  Created by Administrator on 11/29/14.
//  Copyright (c) 2014 Rice University. All rights reserved.
//

#import "Interval.h"
#import "Workout.h"


@implementation Interval

@dynamic lengthInKmOrSeconds;
@dynamic order;
@dynamic pace;
@dynamic typeDistanceOrTime;
@dynamic workout;

@end
