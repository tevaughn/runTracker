//
//  Workout.m
//  Runner
//
//  Created by Administrator on 11/29/14.
//  Copyright (c) 2014 Rice University. All rights reserved.
//

#import "Workout.h"
#import "Interval.h"
#import "Run.h"


@implementation Workout

@dynamic intervalCount;
@dynamic name;
@dynamic selected;
@dynamic runs;
@dynamic intervals;

@end
