//
//  IntervalRecord.m
//  Runner
//
//  Created by Administrator on 11/29/14.
//  Copyright (c) 2014 Rice University. All rights reserved.
//

#import "IntervalRecord.h"
#import "Run.h"


@implementation IntervalRecord

@dynamic timeInS;
@dynamic distanceInKm;
@dynamic order;
@dynamic run;

@end
