//
//  Breadcrumb.m
//  Runner
//
//  Created by Administrator on 11/29/14.
//  Copyright (c) 2014 Rice University. All rights reserved.
//

#import "Breadcrumb.h"
#import "Run.h"


@implementation Breadcrumb

@dynamic latitude;
@dynamic longitude;
@dynamic time;
@dynamic run;

@end
