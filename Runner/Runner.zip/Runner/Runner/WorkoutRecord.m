//
//  WorkoutRecord.m
//  Runner
//
//  Created by Administrator on 11/29/14.
//  Copyright (c) 2014 Rice University. All rights reserved.
//

#import "WorkoutRecord.h"
#import "Run.h"


@implementation WorkoutRecord

@dynamic distanceInKm;
@dynamic timeInS;
@dynamic run;

@end
