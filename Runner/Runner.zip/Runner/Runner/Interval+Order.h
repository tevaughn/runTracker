//
//  Interval+Order.h
//  Runner
//
//  Created by Administrator on 11/29/14.
//  Copyright (c) 2014 Rice University. All rights reserved.
//

#import "Interval.h"

@interface Interval (Order)
@property NSInteger order;
@end
